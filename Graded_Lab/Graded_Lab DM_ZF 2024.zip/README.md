# General Information
Created by :
- Marsoni David
- Zanya Fernandez Rodriguez

Group : DM_ZF

## Lauching the project

To launch the project, you need to run all the cells in the notebook 'Graded_lab.ipynb' in order to get the results of the different questions.

You can use the outline of the projet to navigate through the notebook easily.(some title seems to be small but that is because of the markdown).

## Notes

This notebook was already runned so you can see the results of the different questions in the cells.